export const environment = {
  production: true,
  baseApi: 'http://localhost:8180/'
};
